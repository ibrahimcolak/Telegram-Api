## A Simple RedLineStealer(For Educational Purposes Only)

# As Of 16th Of August 2023 Anonfiles, The File Sharing Platform For This Project Has Shutdown, An Alternative Will Replace The Previous Platform Soon

# Instructions:

![image](https://user-images.githubusercontent.com/94680549/206546946-cbc09f1c-3698-40e6-90a3-9de1f8fc11de.png)

>Replace The Bot API_Key, Proxy Server and Telegram Chat_Id With Your **Own** Before Compiling It

>This Program Was Made For the Sole Purpose Of Learning (Use with Permission)

>**We Do Not Take Responsibility For Misuse Of The Resources Provided In This Repository**


># Donations (Monero):



![Donations](https://github.com/theaqueen21/Merlot/assets/94680549/6b6338a5-0938-4b36-9f76-d51e3b0d53f8)

Thank You In Advance!

